/*
  MYSTERY BOX — FLIRTY VERSION
  Semua konten yang sering diganti ada di CONFIG.
*/

const CONFIG = {
  music: {
    title: "Judul Lagu Kamu",
    artist: "Nama Artist",
    audio: "assets/lagu.mp3",
    cover: "assets/cover.jpg",
    lyricsTitle: "buat nemenin kamu",
    lyrics: `Tulis lirik kamu di sini...

Baris kedua.
Baris ketiga.

Tulis lirik lengkapmu di sini.`
  },

  finish: {
    title: "oke, sekarang jangan senyum-senyum sendiri.",
    text: "Aku tahu kok kamu senyum.",
    words: ["hey", "jangan salting", "ketahuan", "hehe", "santai", "belum nembak kok"]
  },

  photos: [
    { src: "assets/foto1.jpg", caption: "yang ini jangan geer." },
    { src: "assets/foto2.jpg", caption: "oke, yang ini juga." },
    { src: "assets/foto3.jpg", caption: "yang terakhir paling bahaya." }
  ],

  question: {
    title: "Kalau aku sering ganggu kamu,<br><em>kamu keberatan nggak?</em>",
    text: "Jawab jujur. Aku cuma penasaran."
  },

  emailjs: {
    publicKey: "GANTI_PUBLIC_KEY",
    serviceId: "GANTI_SERVICE_ID",
    templateId: "GANTI_TEMPLATE_ID"
  }
};

// ---------- helpers ----------
const $ = s => document.querySelector(s);
const audio = $("#audio");

function formatTime(sec) {
  if (!Number.isFinite(sec)) return "0:00";
  return `${Math.floor(sec / 60)}:${Math.floor(sec % 60).toString().padStart(2,"0")}`;
}

// ---------- local data ----------
function initData() {
  $("#coverImage").src = CONFIG.music.cover;
  $("#songTitle").textContent = CONFIG.music.title;
  $("#songArtist").textContent = CONFIG.music.artist;
  $("#lyricsTitle").textContent = CONFIG.music.lyricsTitle;
  $("#lyrics").textContent = CONFIG.music.lyrics;
  $("#finishTitle").textContent = CONFIG.finish.title;
  $("#finishText").textContent = CONFIG.finish.text;

  CONFIG.photos.forEach((p, i) => {
    const img = document.querySelector(`.photo:nth-child(${i+1}) img`);
    const cap = document.querySelector(`#caption${i+1}`);
    if (img) { img.src = p.src; img.alt = `Foto ${i+1}`; }
    if (cap) cap.textContent = p.caption;
  });

  $("#questionTitle").innerHTML = CONFIG.question.title;
  $("#questionText").textContent = CONFIG.question.text;

  audio.src = CONFIG.music.audio;
}

// ---------- particles ----------
function spawnParticles() {
  const container = $("#particles");
  const colors = ["#d96d91","#a83c59","#efadc4","#7d2945"];
  for (let i=0;i<28;i++) {
    const p = document.createElement("span");
    p.className = "particle";
    const size = 5 + Math.random()*7;
    p.style.left = `${Math.random()*100}%`;
    p.style.top = `${-40-Math.random()*80}px`;
    p.style.width = `${size}px`;
    p.style.height = `${size*1.5}px`;
    p.style.background = colors[Math.floor(Math.random()*colors.length)];
    p.style.animationDuration = `${8+Math.random()*10}s`;
    p.style.animationDelay = `${Math.random()*12}s`;
    container.appendChild(p);
  }
}

// ---------- reveal ----------
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      observer.unobserve(entry.target);
    }
  });
}, {threshold:.14});

document.querySelectorAll(".reveal").forEach(el => observer.observe(el));

// ---------- smooth links ----------
document.querySelectorAll("[data-scroll]").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelector(btn.dataset.scroll)?.scrollIntoView({behavior:"smooth"});
  });
});

// ---------- first mystery box ----------
$("#openBox").addEventListener("click", () => {
  $("#player").scrollIntoView({behavior:"smooth"});
});

// ---------- player ----------
$("#playBtn").addEventListener("click", async () => {
  if (audio.paused) {
    try { await audio.play(); }
    catch { alert("Audio belum bisa diputar. Coba tekan play lagi."); }
  } else {
    audio.pause();
  }
});

audio.addEventListener("play", () => $("#playBtn").textContent = "Ⅱ");
audio.addEventListener("pause", () => $("#playBtn").textContent = "▶");

audio.addEventListener("loadedmetadata", () => {
  $("#total").textContent = formatTime(audio.duration);
});

audio.addEventListener("timeupdate", () => {
  if (!audio.duration) return;
  $("#current").textContent = formatTime(audio.currentTime);
  $("#progress").value = (audio.currentTime/audio.duration)*100;
});

$("#progress").addEventListener("input", e => {
  if (audio.duration) audio.currentTime = audio.duration * (e.target.value/100);
});

$("#backBtn").addEventListener("click", () => {
  audio.currentTime = Math.max(0, audio.currentTime - 10);
});
$("#forwardBtn").addEventListener("click", () => {
  audio.currentTime = Math.min(audio.duration || 0, audio.currentTime + 10);
});

// ---------- song finished ----------
audio.addEventListener("ended", () => {
  const section = $("#afterSong");
  section.scrollIntoView({behavior:"smooth"});
  const holder = $("#floatingWords");

  CONFIG.finish.words.forEach((word, i) => {
    const el = document.createElement("span");
    el.textContent = word;
    el.style.left = `${8+Math.random()*84}%`;
    el.style.animationDelay = `${i*.18}s`;
    el.style.animationDuration = `${4+Math.random()*3}s`;
    holder.appendChild(el);
    setTimeout(() => el.remove(), 7500);
  });
});

// ---------- final box ----------
$("#finalBox").addEventListener("click", () => {
  $("#questionModal").classList.remove("hidden");
  document.body.style.overflow = "hidden";
  setTimeout(() => $("#senderName").focus(), 100);
});

function closeModal() {
  $("#questionModal").classList.add("hidden");
  document.body.style.overflow = "";
}
$("#closeModal").addEventListener("click", closeModal);
$("#questionModal").addEventListener("click", e => {
  if (e.target.id === "questionModal") closeModal();
});
document.addEventListener("keydown", e => {
  if (e.key === "Escape") closeModal();
});

// ---------- answer ----------
let selectedAnswer = "";
document.querySelectorAll(".answer-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    selectedAnswer = btn.dataset.answer;
    document.querySelectorAll(".answer-btn").forEach(b => b.classList.remove("selected"));
    btn.classList.add("selected");
  });
});

// ---------- EmailJS ----------
function emailReady() {
  return CONFIG.emailjs.publicKey !== "GANTI_PUBLIC_KEY" &&
         CONFIG.emailjs.serviceId !== "GANTI_SERVICE_ID" &&
         CONFIG.emailjs.templateId !== "GANTI_TEMPLATE_ID";
}

if (emailReady()) emailjs.init({publicKey: CONFIG.emailjs.publicKey});

$("#answerForm").addEventListener("submit", async e => {
  e.preventDefault();

  const name = $("#senderName").value.trim();
  const message = $("#senderMessage").value.trim();
  const status = $("#status");
  const button = $("#sendBtn");

  if (!name) return showStatus("Isi nama kamu dulu.", "error");
  if (!selectedAnswer) return showStatus("Pilih salah satu jawaban dulu.", "error");

  if (!emailReady()) {
    return showStatus("EmailJS belum dikonfigurasi di script.js.", "error");
  }

  button.disabled = true;
  button.textContent = "mengirim...";

  try {
    await emailjs.send(CONFIG.emailjs.serviceId, CONFIG.emailjs.templateId, {
      from_name: name,
      yn_answer: selectedAnswer,
      message: message || "(tidak ada pesan tambahan)",
      to_name: "Kamu",
      reply_to: ""
    });

    showStatus("jawabanmu sudah terkirim.", "success");
    button.textContent = "terkirim";
  } catch (error) {
    console.error(error);
    showStatus("gagal mengirim. cek konfigurasi EmailJS.", "error");
    button.disabled = false;
    button.textContent = "kirim jawaban";
  }
});

function showStatus(text, type) {
  $("#status").textContent = text;
  $("#status").className = `status ${type}`;
}

initData();
spawnParticles();
